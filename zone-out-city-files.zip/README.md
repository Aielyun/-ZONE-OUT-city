# ZONE OUT — 城市松弛指南

一个独立的、移动端优先的城市休闲探索网站。

## 发布到 GitHub Pages
1. 将 `index.html` 上传到仓库根目录（与 README.md 同级）。
2. 进入仓库 **Settings → Pages**。
3. 在 **Build and deployment** 下选择 **Deploy from a branch**。
4. Branch 选择 `main`，目录选择 `/(root)`，点击 **Save**。
5. 等待发布完成后访问 `https://aielyun.github.io/zone-out-city/`。

## 说明
页面包含搜索、心情筛选、类别筛选、预算/区域筛选和本地收藏。地点卡片是演示用虚构内容，不代表真实商家或实际价格；上线前请替换为已核实的地点数据。
